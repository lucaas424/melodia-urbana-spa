// data.js
// Datos en memoria para la API (sin base de datos)

const users = [
  {
    id: 1,
    name: "Admin",
    email: "admin@melodia.com",
    password: "admin123",
    role: "admin",
  },
  {
    id: 2,
    name: "Lucas",
    email: "lucas@melodia.com",
    password: "123456",
    role: "cliente",
  },
];

const events = [
  {
    id: 1,
    name: "Sesión acústica",
    date: "22/11",
    place: "Sala pequeña",
    status: "Programado",
  },
  {
    id: 2,
    name: "Show en vivo",
    date: "30/11",
    place: "Teatro principal",
    status: "Programado",
  },
];

module.exports = {
  users,
  events,
};
