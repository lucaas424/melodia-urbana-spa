// server.js
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const { users, events } = require("./data");
const { auth, requireRole } = require("./middleware/auth");

const app = express();

app.use(cors());
app.use(express.json());


const JWT_SECRET = "melodia-urbana-super-secreto";


app.get("/api/ping", (req, res) => {
  res.json({ message: "API Melodía Urbana funcionando ✅" });
});


app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res
      .status(400)
      .json({ message: "Email y contraseña son obligatorios" });
  }

  const foundUser = users.find(
    (u) => u.email === email && u.password === password
  );

  if (!foundUser) {
    return res.status(401).json({ message: "Credenciales incorrectas" });
  }

  const payload = {
    id: foundUser.id,
    name: foundUser.name,
    email: foundUser.email,
    role: foundUser.role,
  };

  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: "1h" });

  return res.json({
    message: `Bienvenido/a ${foundUser.name}`,
    user: payload,
    token,
  });
});


app.get("/api/users", auth, requireRole("admin"), (req, res) => {
  const publicUsers = users.map(({ password, ...rest }) => rest);
  res.json(publicUsers);
});


app.patch("/api/users/:id/role", auth, requireRole("admin"), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = users.find((u) => u.id === id);

  if (!user) {
    return res.status(404).json({ message: "Usuario no encontrado" });
  }

  user.role = user.role === "admin" ? "cliente" : "admin";

  const { password, ...publicUser } = user;
  res.json(publicUser);
});


app.get("/api/events", auth, (req, res) => {
  res.json(events);
});


app.post("/api/events", auth, requireRole("admin"), (req, res) => {
  const { name, date, place, status } = req.body;

  
  if (!name || !date || !place) {
    return res
      .status(400)
      .json({ message: "Nombre, fecha y lugar son obligatorios" });
  }

  const newId =
    events.length > 0 ? Math.max(...events.map((e) => e.id)) + 1 : 1;

  const newEvent = {
    id: newId,
    name: String(name).trim(),
    date: String(date).trim(),
    place: String(place).trim(),
    status:
      status && String(status).trim()
        ? String(status).trim()
        : "Programado",
  };

  events.push(newEvent);

  return res.status(201).json(newEvent);
});


app.patch("/api/events/:id", auth, requireRole("admin"), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const event = events.find((e) => e.id === id);

  if (!event) {
    return res.status(404).json({ message: "Evento no encontrado" });
  }

  const { name, date, place, status } = req.body;

  if (typeof name === "string" && name.trim()) {
    event.name = name.trim();
  }
  if (typeof date === "string" && date.trim()) {
    event.date = date.trim();
  }
  if (typeof place === "string" && place.trim()) {
    event.place = place.trim();
  }
  if (typeof status === "string" && status.trim()) {
    event.status = status.trim();
  }

  res.json(event);
});



const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Servidor API escuchando en http://localhost:${PORT}`);
});
