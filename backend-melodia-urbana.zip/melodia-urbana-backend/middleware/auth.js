// middleware/auth.js
const jwt = require("jsonwebtoken");


const JWT_SECRET = "melodia-urbana-super-secreto";


function auth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Token no enviado" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded; // { id, name, email, role }
    next();
  } catch (error) {
    return res.status(401).json({ message: "Token inválido o expirado" });
  }
}


function requireRole(role) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ message: "No autorizado" });
    }
    next();
  };
}

module.exports = {
  auth,
  requireRole,
};
