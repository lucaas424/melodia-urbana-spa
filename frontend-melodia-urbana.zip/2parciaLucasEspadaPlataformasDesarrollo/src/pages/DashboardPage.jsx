// src/pages/DashboardPage.jsx
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const isAdmin = user?.role === "admin";

  const handleOpenEvents = () => {
    navigate("/eventos");
  };

  const handleOpenUsers = () => {
    if (!isAdmin) return;
    navigate("/usuarios");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <header className="flex items-center justify-between px-8 py-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-semibold">
            Bienvenido/a, {user?.name} – Melodía Urbana
          </h1>
          <p className="text-sm text-slate-300 mt-1">
            {isAdmin
              ? "Panel de administración de eventos, shows y usuarios."
              : "Panel de cliente: tus entradas y próximos eventos."}
          </p>
        </div>

        <button
          onClick={logout}
          className="rounded-md bg-rose-600 px-4 py-2 text-sm font-medium hover:bg-rose-500"
        >
          Cerrar sesión
        </button>
      </header>

      <main className="px-8 py-10">
        <p className="text-sm text-slate-300 mb-6">
          En este panel podés acceder rápidamente a la gestión de eventos,
          usuarios y ver los próximos shows.
        </p>

        <div className="grid gap-6 md:grid-cols-3 max-w-5xl">
          
          <button
            type="button"
            onClick={handleOpenEvents}
            className="w-full text-left rounded-xl border border-sky-600/70 bg-slate-800/80 px-6 py-5 hover:bg-slate-800 hover:border-sky-400 transition cursor-pointer"
          >
            <h2 className="text-lg font-semibold mb-1">Eventos</h2>
            <p className="text-sm text-slate-300">
              {isAdmin
                ? "Crear, editar y cancelar eventos y shows."
                : "Ver los eventos disponibles y el estado de tus shows."}
            </p>
          </button>

          
          <button
            type="button"
            onClick={handleOpenUsers}
            disabled={!isAdmin}
            className={`w-full text-left rounded-xl border px-6 py-5 transition ${
              isAdmin
                ? "border-sky-600/70 bg-slate-800/80 hover:bg-slate-800 hover:border-sky-400 cursor-pointer"
                : "border-slate-700/70 bg-slate-800/40 text-slate-400 cursor-not-allowed"
            }`}
          >
            <h2 className="text-lg font-semibold mb-1">Usuarios</h2>
            <p className="text-sm">
              Sección disponible sólo para administradores.
            </p>
          </button>

          
          <div className="w-full text-left rounded-xl border border-slate-700/70 bg-slate-800/80 px-6 py-5">
            <h2 className="text-lg font-semibold mb-1">Próximos shows</h2>
            <p className="text-sm text-slate-300 mb-3">
              Resumen rápido de las próximas fechas y lugares.
            </p>
            <ul className="text-sm text-slate-200 space-y-1">
              <li>🎵 22/11 – Sesión acústica</li>
              <li>🎵 30/11 – Show en vivo</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
}
