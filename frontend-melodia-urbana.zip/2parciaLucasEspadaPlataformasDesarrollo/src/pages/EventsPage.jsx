// src/pages/EventsPage.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import {
  apiGetEvents,
  apiCancelEvent,
  apiUpdateEvent,
  apiCreateEvent,
} from "../services/api";

export default function EventsPage() {
  const { user, token } = useAuth();
  const isAdmin = user?.role === "admin";

  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  
  const [editingId, setEditingId] = useState(null);
  const [editValues, setEditValues] = useState({
    name: "",
    date: "",
    place: "",
    status: "Programado",
  });

  
  const [newEventValues, setNewEventValues] = useState({
    name: "",
    date: "",
    place: "",
    status: "Programado",
  });

  useEffect(() => {
    loadEvents();
    
  }, []);

  async function loadEvents() {
    try {
      setLoading(true);
      setMessage("");
      const data = await apiGetEvents(token);
      setEvents(data);
    } catch (error) {
      setMessage(error.message || "Error al cargar eventos");
    } finally {
      setLoading(false);
    }
  }

  
  const handleCancelEvent = async (id) => {
    if (!isAdmin) return;

    const confirmed = window.confirm(
      "¿Seguro que querés cancelar este evento? (solo cambia el estado en esta demo)."
    );
    if (!confirmed) return;

    try {
      setMessage("");
      const updated = await apiCancelEvent(id, token);
      setEvents((prev) =>
        prev.map((event) => (event.id === updated.id ? updated : event))
      );
      setMessage("Evento cancelado correctamente.");
    } catch (error) {
      setMessage(error.message);
    }
  };

  
  const handleEditClick = (event) => {
    if (!isAdmin) return;

    setEditingId(event.id);
    setEditValues({
      name: event.name,
      date: event.date,
      place: event.place,
      status: event.status,
    });
    setMessage("");
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditValues((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editingId || !isAdmin) return;

    try {
      setMessage("");
      const updated = await apiUpdateEvent(editingId, editValues, token);
      setEvents((prev) =>
        prev.map((event) => (event.id === updated.id ? updated : event))
      );
      setMessage("Evento actualizado correctamente.");
      setEditingId(null);
      setEditValues({
        name: "",
        date: "",
        place: "",
        status: "Programado",
      });
    } catch (error) {
      setMessage(error.message);
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditValues({
      name: "",
      date: "",
      place: "",
      status: "Programado",
    });
  };

  
  const handleNewChange = (e) => {
    const { name, value } = e.target;
    setNewEventValues((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleNewSubmit = async (e) => {
    e.preventDefault();
    if (!isAdmin) return;

    try {
      setMessage("");
      const created = await apiCreateEvent(newEventValues, token);
      setEvents((prev) => [...prev, created]);
      setMessage("Nuevo evento creado correctamente.");
      setNewEventValues({
        name: "",
        date: "",
        place: "",
        status: "Programado",
      });
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-50">
      <div className="max-w-5xl mx-auto px-4 py-10">
        
        <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-8">
          <div>
            <h1 className="text-2xl font-bold">Eventos / Shows</h1>
            <p className="text-sm text-slate-400">
              Gestión básica de eventos para Melodía Urbana. Los datos vienen
              de la API.
            </p>
          </div>

          <p className="text-xs text-slate-400">
            Sesión iniciada como:{" "}
            <span className="font-semibold">{user?.name}</span>{" "}
            <span className="text-slate-500">({user?.role})</span>
          </p>
        </header>

        
        {message && (
          <div className="mb-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-200">
            {message}
          </div>
        )}

        
        <section className="bg-slate-900 rounded-2xl border border-slate-800 p-6">
          <h2 className="text-base font-semibold mb-2">Listado de eventos</h2>
          <p className="text-sm text-slate-400 mb-4">
            {isAdmin
              ? "Acá gestionamos de forma básica los eventos: podés cancelar un show o editar sus datos."
              : "Acá podés ver los shows disponibles y el estado de cada evento."}
          </p>

          {loading ? (
            <p className="text-sm text-slate-400">Cargando eventos...</p>
          ) : events.length === 0 ? (
            <p className="text-sm text-slate-400">
              Por ahora no hay eventos cargados.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-left text-slate-400">
                    <th className="py-2 pr-4 font-medium">Nombre</th>
                    <th className="py-2 pr-4 font-medium">Fecha</th>
                    <th className="py-2 pr-4 font-medium">Lugar</th>
                    <th className="py-2 pr-4 font-medium">Estado</th>
                    {isAdmin && (
                      <th className="py-2 pr-4 font-medium">Acciones</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {events.map((event) => (
                    <tr
                      key={event.id}
                      className="border-b border-slate-900 last:border-0"
                    >
                      <td className="py-2 pr-4">{event.name}</td>
                      <td className="py-2 pr-4">{event.date}</td>
                      <td className="py-2 pr-4">{event.place}</td>
                      <td className="py-2 pr-4">
                        <span
                          className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
                            event.status === "Programado"
                              ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/40"
                              : "bg-rose-500/10 text-rose-300 border border-rose-500/40"
                          }`}
                        >
                          {event.status}
                        </span>
                      </td>
                      {isAdmin && (
                        <td className="py-2 pr-4 space-x-2">
                          <button
                            type="button"
                            onClick={() => handleEditClick(event)}
                            className="inline-flex items-center rounded-lg bg-sky-600 px-3 py-1 text-xs font-medium hover:bg-sky-500"
                          >
                            Editar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCancelEvent(event.id)}
                            className="inline-flex items-center rounded-lg bg-rose-600 px-3 py-1 text-xs font-medium hover:bg-rose-500"
                          >
                            Cancelar
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        
        {isAdmin && (
          <section className="mt-8 bg-slate-900 rounded-2xl border border-slate-800 p-6">
            <h2 className="text-base font-semibold mb-2">Editar evento</h2>

            {editingId == null ? (
              <p className="text-sm text-slate-400">
                Elegí un evento con el botón{" "}
                <span className="font-semibold">Editar</span> para modificar
                nombre, fecha, lugar o estado.
              </p>
            ) : (
              <form
                onSubmit={handleEditSubmit}
                className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4"
              >
                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Nombre</label>
                  <input
                    name="name"
                    value={editValues.name}
                    onChange={handleEditChange}
                    className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Fecha</label>
                  <input
                    name="date"
                    value={editValues.date}
                    onChange={handleEditChange}
                    className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Lugar</label>
                  <input
                    name="place"
                    value={editValues.place}
                    onChange={handleEditChange}
                    className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Estado</label>
                  <select
                    name="status"
                    value={editValues.status}
                    onChange={handleEditChange}
                    className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-600"
                  >
                    <option value="Programado">Programado</option>
                    <option value="Cancelado">Cancelado</option>
                  </select>
                </div>

                <div className="md:col-span-2 flex gap-2 mt-2">
                  <button
                    type="submit"
                    className="rounded-lg bg-sky-600 px-4 py-2 text-sm font-medium hover:bg-sky-500"
                  >
                    Guardar cambios
                  </button>
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium hover:bg-slate-700"
                  >
                    Cancelar edición
                  </button>
                </div>
              </form>
            )}
          </section>
        )}

        
        {isAdmin && (
          <section className="mt-8 bg-slate-900 rounded-2xl border border-slate-800 p-6">
            <h2 className="text-base font-semibold mb-2">Nuevo evento</h2>
            <p className="text-sm text-slate-400 mb-4">
              Completá el formulario para agregar un nuevo show a la agenda.
            </p>

            <form
              onSubmit={handleNewSubmit}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Nombre</label>
                <input
                  name="name"
                  value={newEventValues.name}
                  onChange={handleNewChange}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Nombre del show"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Fecha</label>
                <input
                  name="date"
                  value={newEventValues.date}
                  onChange={handleNewChange}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Ej: 15/12"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Lugar</label>
                <input
                  name="place"
                  value={newEventValues.place}
                  onChange={handleNewChange}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Ej: Teatro principal"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Estado</label>
                <select
                  name="status"
                  value={newEventValues.status}
                  onChange={handleNewChange}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Programado">Programado</option>
                  <option value="Cancelado">Cancelado</option>
                </select>
              </div>

              <div className="md:col-span-2 mt-2">
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium hover:bg-emerald-500"
                >
                  Crear evento
                </button>
              </div>
            </form>
          </section>
        )}
      </div>
    </main>
  );
}
