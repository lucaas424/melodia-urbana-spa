// src/pages/Login.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

    const handleSubmit = async (e) => {
    e.preventDefault();

    const result = await login(email, password);

    setMessage(result.message);

    if (result.ok) {
      navigate("/");
    }
  };


  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="w-full max-w-md bg-slate-800 rounded-xl shadow-lg p-8">
        <h1 className="text-2xl font-bold text-white mb-6 text-center">
          Melodía Urbana – Iniciar sesión
        </h1>

        {message && (
          <div className="mb-4 text-sm text-center text-sky-300">
            {message}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-200 mb-1">
              Email
            </label>
            <input
              type="email"
              className="w-full rounded-md px-3 py-2 bg-slate-900 border border-slate-600 text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm text-slate-200 mb-1">
              Contraseña
            </label>
            <input
              type="password"
              className="w-full rounded-md px-3 py-2 bg-slate-900 border border-slate-600 text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full mt-4 bg-sky-600 hover:bg-sky-500 text-white font-semibold py-2 rounded-md transition"
          >
            Entrar
          </button>
        </form>

        <p className="mt-6 text-xs text-slate-400 text-center">
          Usuario admin por defecto: <br />
          <span className="font-mono">admin@melodia.com</span> /{" "}
          <span className="font-mono">admin123</span>
        </p>
      </div>
    </div>
  );
}
