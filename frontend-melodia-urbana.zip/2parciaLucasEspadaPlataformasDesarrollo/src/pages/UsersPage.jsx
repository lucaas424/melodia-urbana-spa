// src/pages/UsersPage.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";
import { apiGetUsers, apiToggleUserRole } from "../services/api";

export default function UsersPage() {
  const { users, setUsers, user, token } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const isAdmin = user?.role === "admin";

  useEffect(() => {
    
    if (!token) {
      navigate("/login");
      return;
    }

    
    if (!isAdmin) {
      navigate("/");
      return;
    }

    async function loadUsers() {
      try {
        const data = await apiGetUsers(token);
        setUsers(data);
        setMessage("");
      } catch (error) {
        console.error(error);
        setMessage(error.message || "Error al cargar usuarios.");
      } finally {
        setLoading(false);
      }
    }

    loadUsers();
  }, [token, isAdmin, navigate, setUsers]);

  const handleToggleRole = async (id) => {
    try {
      const updatedUser = await apiToggleUserRole(id, token);

      const updatedList = users.map((u) =>
        u.id === id ? updatedUser : u
      );

      setUsers(updatedList);
      setMessage("Rol actualizado correctamente.");
    } catch (error) {
      console.error(error);
      setMessage(error.message || "Error al cambiar el rol.");
    }
  };

  const handleDelete = (id) => {
    const confirmed = window.confirm(
      "¿Seguro que querés eliminar este usuario? (solo se oculta en esta vista, no se borra de la API)."
    );
    if (!confirmed) return;

    const filtered = users.filter((u) => u.id !== id);
    setUsers(filtered);
    setMessage("Usuario eliminado de la tabla.");
  };

  const handleBackToDashboard = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <header className="flex items-center justify-between px-8 py-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-semibold">Gestión de usuarios</h1>
          <p className="text-sm text-slate-300 mt-1">
            Listado básico de usuarios y roles (datos desde la API).
          </p>
        </div>

        <div className="flex items-center gap-4">
          <p className="text-sm text-slate-300">
            Sesión iniciada como:{" "}
            <span className="font-semibold">{user?.name}</span>{" "}
            <span className="text-xs text-slate-400">({user?.role})</span>
          </p>

          <button
            onClick={handleBackToDashboard}
            className="rounded-md bg-slate-800 px-4 py-2 text-sm hover:bg-slate-700 border border-slate-700"
          >
            Volver al panel
          </button>
        </div>
      </header>

      <main className="px-8 py-8">
        <section className="max-w-4xl space-y-6">
          <p className="text-sm text-slate-300">
            Acá se gestiona de forma simple la administración de usuarios:
            mails, roles y acciones básicas. Los datos vienen de la API.
          </p>

          {message && (
            <div className="rounded-lg border border-emerald-600/60 bg-emerald-900/40 px-4 py-3 text-sm text-emerald-50">
              {message}
            </div>
          )}

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-700">
              <h2 className="text-lg font-semibold">Usuarios registrados</h2>
            </div>

            <table className="w-full text-sm">
              <thead className="bg-slate-800/90">
                <tr className="text-left text-slate-300">
                  <th className="px-6 py-3">Nombre</th>
                  <th className="px-6 py-3">Email</th>
                  <th className="px-6 py-3">Rol</th>
                  <th className="px-6 py-3">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td
                      colSpan="4"
                      className="px-6 py-4 text-center text-slate-400"
                    >
                      Cargando usuarios...
                    </td>
                  </tr>
                )}

                {!loading &&
                  users.map((u) => (
                    <tr
                      key={u.id}
                      className="border-t border-slate-700/70 hover:bg-slate-800/60"
                    >
                      <td className="px-6 py-3">{u.name}</td>
                      <td className="px-6 py-3">{u.email}</td>
                      <td className="px-6 py-3">
                        <span
                          className={
                            u.role === "admin"
                              ? "inline-flex px-2 py-1 text-xs rounded bg-emerald-600/80"
                              : "inline-flex px-2 py-1 text-xs rounded bg-sky-600/80"
                          }
                        >
                          {u.role}
                        </span>
                      </td>
                      <td className="px-6 py-3 space-x-2">
                        <button
                          onClick={() => handleToggleRole(u.id)}
                          className="px-3 py-1 text-xs rounded bg-sky-600 hover:bg-sky-500"
                        >
                          Editar rol
                        </button>
                        <button
                          onClick={() => handleDelete(u.id)}
                          className="px-3 py-1 text-xs rounded bg-rose-600 hover:bg-rose-500"
                        >
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}

                {!loading && users.length === 0 && (
                  <tr>
                    <td
                      colSpan="4"
                      className="px-6 py-4 text-center text-slate-400"
                    >
                      No hay usuarios para mostrar.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 p-6">
            <h3 className="text-base font-semibold mb-2">
              Acciones disponibles:
            </h3>
            <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
              <li>Cambiar el rol entre admin y cliente.</li>
              <li>Simular la baja de un usuario en la tabla.</li>
            </ul>
          </div>
        </section>
      </main>
    </div>
  );
}
