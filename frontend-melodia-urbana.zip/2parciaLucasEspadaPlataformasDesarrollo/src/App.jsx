// src/App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import EventsPage from "./pages/EventsPage.jsx";
import UsersPage from "./pages/UsersPage.jsx";
import { useAuth } from "./context/AuthContext.jsx";

function PrivateRoute({ children, role }) {
  const { user } = useAuth();

  
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  
  if (role && user.role !== role) {
    return <Navigate to="/" replace />;
  }

  return children;
}

export default function App() {
  return (
    <Routes>
      {}
      <Route path="/login" element={<Login />} />

      {}
      <Route
        path="/"
        element={
          <PrivateRoute>
            <DashboardPage />
          </PrivateRoute>
        }
      />

      {}
      <Route
        path="/eventos"
        element={
          <PrivateRoute role="admin">
            <EventsPage />
          </PrivateRoute>
        }
      />

      {}
      <Route
        path="/usuarios"
        element={
          <PrivateRoute role="admin">
            <UsersPage />
          </PrivateRoute>
        }
      />

      {}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
