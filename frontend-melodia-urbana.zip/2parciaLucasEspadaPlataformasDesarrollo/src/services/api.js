// src/services/api.js

const API_URL = "http://localhost:4000/api";


async function handleResponse(res, defaultMessage) {
  if (!res.ok) {
    let errorMessage = defaultMessage;

    try {
      const errorData = await res.json();
      if (errorData.message) errorMessage = errorData.message;
    } catch (e) {
      
    }

    throw new Error(errorMessage);
  }

  return res.json();
}



export async function apiLogin(email, password) {
  const res = await fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

  return handleResponse(res, "Error al iniciar sesión");
}



export async function apiGetUsers(token) {
  const res = await fetch(`${API_URL}/users`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return handleResponse(res, "Error al obtener usuarios");
}

export async function apiDeleteUser(id, token) {
  const res = await fetch(`${API_URL}/users/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return handleResponse(res, "Error al eliminar usuario");
}

export async function apiToggleUserRole(id, token) {
  const res = await fetch(`${API_URL}/users/${id}/role`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return handleResponse(res, "Error al cambiar rol de usuario");
}



export async function apiGetEvents(token) {
  const res = await fetch(`${API_URL}/events`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return handleResponse(res, "Error al obtener eventos");
}

export async function apiCancelEvent(id, token) {
  const res = await fetch(`${API_URL}/events/${id}/cancel`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  return handleResponse(res, "Error al cancelar evento");
}

export async function apiUpdateEvent(id, payload, token) {
  const res = await fetch(`${API_URL}/events/${id}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  return handleResponse(res, "Error al editar evento");
}

export async function apiCreateEvent(payload, token) {
  const res = await fetch(`${API_URL}/events`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  return handleResponse(res, "Error al crear evento");
}
