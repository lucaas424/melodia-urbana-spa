// src/context/AuthContext.jsx
import { createContext, useContext, useState } from "react";
import { apiLogin } from "../services/api";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);   
  const [token, setToken] = useState(null); 
  const [users, setUsers] = useState([]);   

  
  const login = async (email, password) => {
    try {
      const data = await apiLogin(email, password); 

      setUser(data.user);
      setToken(data.token);

      return {
        ok: true,
        message: data.message || "Login correcto",
      };
    } catch (error) {
      return {
        ok: false,
        message: error.message || "Error al iniciar sesión",
      };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setUsers([]); 
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        users,
        setUsers,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
