// src/components/DashboardCard.jsx
import { Link } from "react-router-dom";

export default function DashboardCard({ title, description, to, children }) {
  const Wrapper = to ? Link : "div";

  return (
    <Wrapper
      to={to}
      className={`block bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md hover:border-sky-500 hover:shadow-lg transition ${
        to ? "cursor-pointer" : ""
      }`}
    >
      <h2 className="text-lg font-semibold mb-1">{title}</h2>
      <p className="text-sm text-slate-300 mb-3">{description}</p>
      {children}
    </Wrapper>
  );
}
