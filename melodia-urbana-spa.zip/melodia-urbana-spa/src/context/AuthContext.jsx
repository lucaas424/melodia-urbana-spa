// src/context/AuthContext.jsx
import { createContext, useContext, useState } from "react";


const initialUsers = [
  {
    id: 1,
    name: "Admin",
    email: "admin@melodia.com",
    password: "admin123",
    role: "admin",
  },
  {
    id: 2,
    name: "Lucas",
    email: "lucas@melodia.com",
    password: "123456",
    role: "cliente",
  },
];

const AuthContext = createContext();


export const AuthProvider = ({ children }) => {
  const [users, setUsers] = useState(initialUsers);
  const [user, setUser] = useState(null); 

  const login = (email, password) => {
    const foundUser = users.find(
      (u) => u.email === email && u.password === password
    );

    if (!foundUser) {
      return { ok: false, message: "Credenciales incorrectas" };
    }

    setUser(foundUser);
    return { ok: true, message: `Bienvenido/a ${foundUser.name}` };
  };

  const logout = () => {
    setUser(null);
  };

  const register = ({ name, email, password, role }) => {
    const exists = users.some((u) => u.email === email);

    if (exists) {
      return { ok: false, message: "Ya existe un usuario con ese email" };
    }

    const newUser = {
      id: users.length + 1,
      name,
      email,
      password,
      role: role || "cliente",
    };

    setUsers([...users, newUser]);
    return { ok: true, message: "Usuario creado correctamente" };
  };

  return (
  <AuthContext.Provider
    value={{ user, users, setUsers, login, logout, register }}
  >
    {children}
  </AuthContext.Provider>
);

};


export const useAuth = () => {
  return useContext(AuthContext);
};
