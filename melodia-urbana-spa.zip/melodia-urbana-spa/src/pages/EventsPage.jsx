// src/pages/EventsPage.jsx
import { useAuth } from "../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

const mockEvents = [
  {
    id: 1,
    name: "Sesión acústica",
    date: "22/11",
    place: "Sala pequeña",
    status: "Programado",
  },
  {
    id: 2,
    name: "Show en vivo",
    date: "30/11",
    place: "Teatro principal",
    status: "Programado",
  },
];

export default function EventsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleBackToDashboard = () => {
    navigate("/dashboard");
  };

  const handleEdit = (eventId) => {
    alert(`Acá en una segunda etapa se editaría el evento con id ${eventId}.`);
  };

  const handleCancel = (eventId) => {
    alert(`Acá se podría cancelar el evento con id ${eventId}.`);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <header className="flex items-center justify-between px-8 py-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-semibold">Eventos / Shows</h1>
          <p className="text-sm text-slate-300 mt-1">
            Gestión básica de eventos para Melodía Urbana.
          </p>
        </div>

        <div className="flex items-center gap-4">
          <p className="text-sm text-slate-300">
            Sesión iniciada como:{" "}
            <span className="font-semibold">{user?.name}</span>{" "}
            <span className="text-xs text-slate-400">({user?.role})</span>
          </p>

          <button
            onClick={handleBackToDashboard}
            className="rounded-md bg-slate-800 px-4 py-2 text-sm hover:bg-slate-700 border border-slate-700"
          >
            Volver al panel
          </button>
        </div>
      </header>

      <main className="px-8 py-8">
        <section className="max-w-4xl space-y-6">
          <p className="text-sm text-slate-300">
            Acá gestionamos de forma básica los eventos: por ahora se puede
            cancelar un show y ver el cambio en el estado.
          </p>

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-700">
              <h2 className="text-lg font-semibold">Listado de eventos</h2>
            </div>

            <table className="w-full text-sm">
              <thead className="bg-slate-800/90">
                <tr className="text-left text-slate-300">
                  <th className="px-6 py-3">Nombre</th>
                  <th className="px-6 py-3">Fecha</th>
                  <th className="px-6 py-3">Lugar</th>
                  <th className="px-6 py-3">Estado</th>
                  <th className="px-6 py-3">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {mockEvents.map((event) => (
                  <tr
                    key={event.id}
                    className="border-t border-slate-700/70 hover:bg-slate-800/60"
                  >
                    <td className="px-6 py-3">{event.name}</td>
                    <td className="px-6 py-3">{event.date}</td>
                    <td className="px-6 py-3">{event.place}</td>
                    <td className="px-6 py-3">{event.status}</td>
                    <td className="px-6 py-3 space-x-2">
                      <button
                        onClick={() => handleEdit(event.id)}
                        className="px-3 py-1 text-xs rounded bg-sky-600 hover:bg-sky-500"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => handleCancel(event.id)}
                        className="px-3 py-1 text-xs rounded bg-rose-600 hover:bg-rose-500"
                      >
                        Cancelar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 p-6">
            <h3 className="text-base font-semibold mb-2">Próximos pasos:</h3>
            <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
              <li>Agregar un formulario para crear nuevos eventos.</li>
              <li>Permitir editar y cambiar más datos del show.</li>
            </ul>
          </div>
        </section>
      </main>
    </div>
  );
}
