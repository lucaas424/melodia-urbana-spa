// src/pages/UsersPage.jsx
import { useAuth } from "../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

export default function UsersPage() {
  const { users, setUsers, user } = useAuth();
  const navigate = useNavigate();

  const handleToggleRole = (id) => {
    const updated = users.map((u) =>
      u.id === id ? { ...u, role: u.role === "admin" ? "cliente" : "admin" } : u
    );
    setUsers(updated);
  };

  const handleDelete = (id) => {
    const confirmed = window.confirm(
      "¿Seguro que querés eliminar este usuario? (solo se elimina en esta vista para el parcial)"
    );
    if (!confirmed) return;

    const filtered = users.filter((u) => u.id !== id);
    setUsers(filtered);
  };

  const handleBackToDashboard = () => {
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <header className="flex items-center justify-between px-8 py-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-semibold">Gestión de usuarios</h1>
          <p className="text-sm text-slate-300 mt-1">
            Listado básico de usuarios y roles (datos harcodeados).
          </p>
        </div>

        <div className="flex items-center gap-4">
          <p className="text-sm text-slate-300">
            Sesión iniciada como:{" "}
            <span className="font-semibold">{user?.name}</span>{" "}
            <span className="text-xs text-slate-400">({user?.role})</span>
          </p>

          <button
            onClick={handleBackToDashboard}
            className="rounded-md bg-slate-800 px-4 py-2 text-sm hover:bg-slate-700 border border-slate-700"
          >
            Volver al panel
          </button>
        </div>
      </header>

      <main className="px-8 py-8">
        <section className="max-w-4xl space-y-6">
          <p className="text-sm text-slate-300">
            Acá se gestiona de forma simple la administración de usuarios: mails,
            roles y acciones básicas.
          </p>

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-700">
              <h2 className="text-lg font-semibold">Usuarios registrados</h2>
            </div>

            <table className="w-full text-sm">
              <thead className="bg-slate-800/90">
                <tr className="text-left text-slate-300">
                  <th className="px-6 py-3">Nombre</th>
                  <th className="px-6 py-3">Email</th>
                  <th className="px-6 py-3">Rol</th>
                  <th className="px-6 py-3">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr
                    key={u.id}
                    className="border-t border-slate-700/70 hover:bg-slate-800/60"
                  >
                    <td className="px-6 py-3">{u.name}</td>
                    <td className="px-6 py-3">{u.email}</td>
                    <td className="px-6 py-3">
                      <span
                        className={
                          u.role === "admin"
                            ? "inline-flex px-2 py-1 text-xs rounded bg-emerald-600/80"
                            : "inline-flex px-2 py-1 text-xs rounded bg-sky-600/80"
                        }
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="px-6 py-3 space-x-2">
                      <button
                        onClick={() => handleToggleRole(u.id)}
                        className="px-3 py-1 text-xs rounded bg-sky-600 hover:bg-sky-500"
                      >
                        Editar rol
                      </button>
                      <button
                        onClick={() => handleDelete(u.id)}
                        className="px-3 py-1 text-xs rounded bg-rose-600 hover:bg-rose-500"
                      >
                        Eliminar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-800/80 rounded-xl border border-slate-700/70 p-6">
            <h3 className="text-base font-semibold mb-2">Próximos pasos:</h3>
            <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
              <li>Crear usuarios desde un formulario de alta.</li>
              <li>Modificar roles (admin / cliente) de forma más completa.</li>
            </ul>
          </div>
        </section>
      </main>
    </div>
  );
}
