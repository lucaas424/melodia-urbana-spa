// src/pages/DashboardPage.jsx
import { useAuth } from "../context/AuthContext";
import DashboardCard from "../components/DashboardCard";

export default function DashboardPage() {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
  };

  const isAdmin = user?.role === "admin";

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      {}
      <header className="flex items-center justify-between px-8 py-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-semibold">
            Bienvenido/a, {user?.name} – Melodía Urbana
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            {isAdmin
              ? "Panel de administración de eventos, shows y usuarios."
              : "Panel de cliente: tus entradas y próximos eventos."}
          </p>
        </div>

        <button
          onClick={handleLogout}
          className="rounded-md bg-red-500 px-4 py-2 text-sm font-medium hover:bg-red-600 transition"
        >
          Cerrar sesión
        </button>
      </header>

      {}
            <main className="px-8 py-8">
        <p className="text-sm text-slate-300 mb-6">
          Este es el panel principal. Proximamente acá vamos a mostrar la
          gestión de eventos, shows y usuarios.
        </p>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DashboardCard
            title="Eventos"
            description="Crear, editar y cancelar eventos y shows."
            to="/eventos"
          >
            <p className="text-xs text-slate-400">
              Próximamente: listado y formularios.
            </p>
          </DashboardCard>

          <DashboardCard
            title="Usuarios"
            description="Gestionar usuarios, roles y accesos."
            to="/usuarios"
          >
            <p className="text-xs text-slate-400">
              Próximamente: alta, baja y edición.
            </p>
          </DashboardCard>

          <DashboardCard
            title="Próximos shows"
            description="Resumen rápido de fechas y lugares."
          >
            <ul className="text-xs text-slate-400 space-y-1">
              <li>🎵 22/11 – Sesión acústica</li>
              <li>🎵 30/11 – Show en vivo</li>
            </ul>
          </DashboardCard>
        </section>
      </main>

    </div>
  );
}
